<?php

class User_model {
    private $nama = 'Aldo';

    public function getUser() {
        return $this->nama;
    }
}