<?php

define('BASEURL', 'http://localhost/prakweb_2024_x_223040137/MVC/Materi02/public');

//DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mvc');